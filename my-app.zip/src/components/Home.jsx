import { Box } from '@mui/material';
import ApexChart from './Apex'
import ApexChart1 from './Apex1'
const Home = () => {
    return (
        <Box container>
            <ApexChart />
            <ApexChart1 />
        </Box>
    )
}

export default Home;